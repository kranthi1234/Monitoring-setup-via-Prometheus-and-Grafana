# Grafana role

In this role, we are installing grafana of a specified version number. Copying configration file and restart grafana for it to start using this new config file.
Finally confirming whether granfa is working fine.

In this role, we setup grafana to work as expected.

### Variable
version: Version of grafana to be downloaded